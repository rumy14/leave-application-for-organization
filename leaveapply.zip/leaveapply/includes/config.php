<?php

define('DB_HOST','localhost');
define('DB_USER','kolpolok_kolpolok_leave_staff');
define('DB_PASS','0Lzb51H*pV*Y');
define('DB_NAME','kolpolok_leave_staff');

$conn = mysqli_connect('localhost','kolpolok_kolpolok_leave_staff','0Lzb51H*pV*Y','kolpolok_leave_staff') or die(mysqli_error());

// Establish database connection.
try
{
$dbh = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME,DB_USER, DB_PASS,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}
catch (PDOException $e)
{
exit("Error: " . $e->getMessage());
}

?>
