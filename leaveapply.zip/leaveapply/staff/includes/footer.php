<div class="footer-wrap pd-20 mb-20 card-box">
				ACI Leave System <a href="https://kolpolok.com/" target="_blank"><span>developed by </span> Kolpolok Limited</a>
			</div>